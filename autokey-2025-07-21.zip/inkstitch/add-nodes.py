import os 
import pyautogui

def clicky_thing(file_path, doclick=1):
	try:
		location = pyautogui.locateCenterOnScreen(file_path)
		if location:
			# dialog.info_dialog("", f"Found at: , {location.x}: {location.y}")
			pyautogui.moveTo(location.x, location.y, .5, pyautogui.easeInOutQuad)
			if doclick == 1:
				pyautogui.click()
			pyautogui.move(-150, 100, .2)
		else:
			dialog.info_dialog("", f"Image not found")
			exit()
	except Exception as e:
		dialog.info_dialog("", f"An error occurred: {e}")
		exit()
	
def key_send(keyToSend, iLoop=1):
	for i in range(iLoop):	
		keyboard.send_keys(keyToSend)
		time.sleep(.2)


time.sleep(.25)
file_path = "/home/william/autokey_20250414/inkstitch/pygui-add-nodes.png"
clicky_thing(file_path)

