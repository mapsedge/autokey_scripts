import os
import pyautogui
#Enter script code
time.sleep(.5)
#xy = mouse.get_location()

options = ["Join", "Break Path", "Join with Segment", "Delete Segment"]
title = "Choose a value"
message = "Select one of the options"

choice = dialog.list_menu(options, title=title, message=message)
choice = choice.data

file_path = ""
breakApart = False

if choice == 'Join':
	file_path = "/home/william/autokey_20250414/inkstitch/pygui-join-nodes.png"

if choice == 'Break Path':
	file_path = "/home/william/autokey_20250414/inkstitch/pygui-break-path.png"
	breakApart = True

if choice == 'Join with Segment':
	file_path = "/home/william/autokey_20250414/inkstitch/pygui-join-nodes-w-path.png"

if choice == 'Delete Segment':
	file_path = "/home/william/autokey_20250414/inkstitch/pygui-delete-segment.png"
	breakApart = True

# dialog.info_dialog("", file_path)

if os.path.exists(file_path):
	dialog.info_dialog("", "File exists.")
else:
	dialog.info_dialog("", f"{file_path} does not exist.")

try:
	location = pyautogui.locateCenterOnScreen(file_path)
	if location:
		# dialog.info_dialog("", f"Found at: , {location.x}: {location.y}")
		pyautogui.moveTo(location.x, location.y, .5, pyautogui.easeInOutQuad)
		pyautogui.click()
		if breakApart == True:
			time.sleep(.2)
			keyboard.send_keys("<shift>+<ctrl>+k")
	else:
		dialog.info_dialog("", f"Image not found")
except Exception as e:
	dialog.info_dialog("", f"An error occurred: {e}")


# mouse.click_absolute(2127, 80, 1)
# time.sleep(.1)
# mouse.click_absolute(2332, 120, 1)

# mouse.move_cursor(xy[0], xy[1])