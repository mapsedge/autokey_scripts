time.sleep(.5)


for _ in range(12):
	time.sleep(.1)
	keyboard.send_keys("<alt>+<right>")
	time.sleep(.1)
	keyboard.send_keys("<alt>+<up>")




