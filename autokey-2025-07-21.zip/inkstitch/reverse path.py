#Enter script code

keyboard.send_keys("<ctrl>+s")
time.sleep(.5)

keyboard.send_keys("<alt>+p")
time.sleep(.5)
keyboard.send_keys("<up>")
time.sleep(.03)
keyboard.send_keys("<up>")
time.sleep(.03)
keyboard.send_keys("<up>")
time.sleep(.03)
keyboard.send_keys("<up>")
time.sleep(.03)
keyboard.send_keys("<enter>")
