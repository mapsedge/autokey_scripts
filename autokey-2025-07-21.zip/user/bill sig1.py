output = "Bill Morris, owner/semster"
keyboard.send_keys(output)
time.sleep(.3)

output = "\r\n"
keyboard.send_keys(output)
time.sleep(.2)

output = "Seamlyne Reproductions"
keyboard.send_keys(output)
time.sleep(.1)

output = "\r\n"
keyboard.send_keys(output)
time.sleep(.1)

output = "\r\n"
keyboard.send_keys(output)
time.sleep(.1)

output = "Keep up with our latest sales and news. Go to http://eepurl.com/C0rB1 and sign up for our mailing list."
keyboard.send_keys(output)
time.sleep(.1)

output = "\r\n"
keyboard.send_keys(output)
time.sleep(.2)

output = "Check our our Zazzle store for Seamlyne and tights themed merchandise: http://www.zazzle.com/seamlyne"
keyboard.send_keys(output)
time.sleep(.2)

output = "\r\n"
keyboard.send_keys(output)
time.sleep(.2)

output = "Visit our website at http://www.seamlyne.com for the most comfortable tights you will ever wear, period.\r\n"
keyboard.send_keys(output)

