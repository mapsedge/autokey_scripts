# Enter script code
time.sleep(.5)
keyboard.send_keys("<ctrl>+x")
time.sleep(.02)
keyboard.send_keys("<i>")
time.sleep(.02)
keyboard.send_keys("<ctrl>+v")
time.sleep(.02)
keyboard.send_keys("</i>")


