# Enter script code
keyboard.send_keys("miscFx_isset(['', '']);")
i = 1
while i <= 8:
    keyboard.send_key("<left>")
    i += 1