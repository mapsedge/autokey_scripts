output = "Bill Morris"
keyboard.send_keys(output)
time.sleep(.3)
output = "\r\n"
keyboard.send_keys(output)
time.sleep(.2)
output = "Guitar, bouzouki, vocals \r\n"
keyboard.send_keys(output)
time.sleep(.1)
output = "Playing the music of England, Ireland, Scotland, Wales, and of course, America. \r\n"
keyboard.send_keys(output)
time.sleep(.1)
output = "Celtic flavor, modern flair \r\n \r\n"
keyboard.send_keys(output)
time.sleep(.1)
output = "http://www.billmorrismusic.me \r\n"
keyboard.send_keys(output)

