# Enter script code
import sys
counter = system.exec_command("date '+%s'")

active_title = window.get_active_title()

if '.asp' in active_title:
    clipboard.fill_clipboard("writeout \"[" + counter + "] \" & now, 2")
    keyboard.send_keys("<ctrl>+v")
    exit
    
if '.php' in active_title:
    keyboard.send_keys('$s->writeout(date("Y/m/d H:i:s"), 2);')
    exit

if '.js' in active_title:
    keyboard.send_keys('let testDate = new Date(); console.log("' + counter + '", testDate);')
    exit
