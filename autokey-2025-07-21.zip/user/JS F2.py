#winClass = window.get_active_class()
#dialog.info_dialog(title='Window class', message=winClass)


active_title = window.get_active_title()

if '.js' in active_title:

	keyboard.send_keys("<ctrl>+c")
	time.sleep(.2)

	keyboard.send_keys("<down>")
	time.sleep(.1)

	keyboard.send_keys("<ctrl>+f")
	time.sleep(.1)

	keyboard.send_keys("<ctrl>+a")
	time.sleep(.1)

	keyboard.send_keys("<ctrl>+v")
	time.sleep(.1)

	keyboard.send_keys("<enter>")
	time.sleep(.2)

	keyboard.send_keys("<escape>")

	exit()

activeclass = window.get_active_class()
if activeclass == 'kate.kate':

	keyboard.send_keys("<ctrl>+c")
	time.sleep(.2)

	keyboard.send_keys("<shift>+<ctrl>+f")
	time.sleep(.2)

	keyboard.send_keys("<ctrl>+a")
	time.sleep(.2)

	keyboard.send_keys("<ctrl>+v")
	time.sleep(.2)

	keyboard.send_keys("<enter>")
	time.sleep(.2)

	keyboard.send_keys("<escape>")


