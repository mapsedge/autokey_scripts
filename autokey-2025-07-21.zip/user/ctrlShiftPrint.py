import os 
import pyautogui

def clicky_thing(file_path, doclick=1):
	try:
		location = pyautogui.locateCenterOnScreen(file_path)
		if location:
			# dialog.info_dialog("", f"Found at: , {location.x}: {location.y}")
			pyautogui.moveTo(location.x, location.y, .5, pyautogui.easeInOutQuad)
			if doclick == 1:
				pyautogui.click()
			pyautogui.move(-150, 100, .2)
		else:
			dialog.info_dialog("", f"Image not found")
			exit()
	except Exception as e:
		dialog.info_dialog("", f"An error occurred: {e}")
		exit()
	
def key_send(keyToSend, iLoop=1):
	for i in range(iLoop):	
		keyboard.send_keys(keyToSend)
		time.sleep(.2)

def _main():
	time.sleep(.3)
	keyboard.send_keys("<ctrl>+<shift>+p")
	time.sleep(1)

	file_path = "/home/william/autokey_20250414/user/print_device_selection.png"
	clicky_thing(file_path)

	""" if os.path.exists(file_path):
		dialog.info_dialog("", "File exists.")
	else:
		dialog.info_dialog("", f"{file_path} does not exist.")
	"""


	file_path = "/home/william/autokey_20250414/user/print_button_pagesetup.png"
	clicky_thing(file_path)

	time.sleep(.5)

	# paper type
	key_send("<tab>", 3)
	key_send("<down>")

	# tray
	key_send("<tab>")
	key_send("<down>")

	# page size
	key_send("<tab>")
	key_send("<home>")

	file_path = "/home/william/autokey_20250414/user/print_button.png"
	clicky_thing(file_path)

_main()