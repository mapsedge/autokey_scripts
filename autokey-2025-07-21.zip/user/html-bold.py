# Enter script code
time.sleep(.2)
keyboard.send_keys("<ctrl>+x")
time.sleep(.02)
keyboard.send_keys("<b>")
time.sleep(.02)
keyboard.send_keys("<ctrl>+v")
time.sleep(.02)
keyboard.send_keys("</b>")

