from datetime import date

keyboard.send_keys(date.today().strftime("%Y-%m-%d"))
time.sleep(.5)
keyboard.release_key("<alt>");
keyboard.release_key("<control>");
keyboard.release_key("<shift>");
