
import time
# Enter script code
active_title = window.get_active_title()
time.sleep(.3)
if '.asp' in active_title:
    clipboard.fill_clipboard("'---------------------------------------------------------------------------------")
    
if '.php' in active_title:
    clipboard.fill_clipboard("//---------------------------------------------------------------------------------")

if '.js' in active_title:
    clipboard.fill_clipboard("//---------------------------------------------------------------------------------")
 
time.sleep(.3)
keyboard.send_keys("<enter>")
time.sleep(.05)
keyboard.send_keys("<up>")
time.sleep(.05)
keyboard.send_keys("<ctrl>+v")
time.sleep(.05)
keyboard.send_keys("<home>")
time.sleep(.05)
keyboard.send_keys("<down>")
