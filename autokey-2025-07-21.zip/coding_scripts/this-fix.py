#Enter script code
time.sleep(.1)
keyboard.send_keys("<escape>")
time.sleep(.1)
keyboard.send_keys("<end>")