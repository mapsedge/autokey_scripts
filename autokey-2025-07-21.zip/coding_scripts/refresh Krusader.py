#!/bin/env python3
# Created by atbswp v0.3.0 (https://git.sr.ht/~rmpr/atbswp)
# on 15 Jul 2025 
import pyautogui
import time
pyautogui.FAILSAFE = False

time.sleep(.1)
keyboard.send_keys("<ctrl>+a")
time.sleep(1)
pyautogui.moveTo(1203, 274)
time.sleep(1)

pyautogui.mouseDown(button='left')

pyautogui.moveTo(450, 450, 1, pyautogui.easeInOutQuad)

time.sleep(.05)
pyautogui.keyDown('ctrlleft')
time.sleep(.05)
pyautogui.mouseUp(button='left')
time.sleep(.05)
pyautogui.keyUp('ctrlleft')

if window.wait_for_exist("File Already Exists", 5):
	time.sleep(.1)
	keyboard.send_keys("<alt>+y")
	time.sleep(.2)
	keyboard.send_keys("<alt>+o")

exit(0)
