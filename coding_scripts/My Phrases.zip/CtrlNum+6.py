import mapsedge_save

def cutSelection():
    keyboard.send_keys("<end>")
    time.sleep(.2)
    keyboard.send_keys("<shift>+<home>")
    time.sleep(.2)
    selText = clipboard.get_selection()
    time.sleep(.6)    
    keyboard.send_keys("<delete>")
    return selText

def getLabel():
    secs = str(time.time())
    return secs[-6:]

winTitle = window.get_active_title()
label = getLabel()
selText = cutSelection()

selText2 = selText.replace("\"", "\\\"")
selText_php = selText2.replace("$", "\$")

#die(print_r("[]", 1)); 
#console.log("[] " + $x)

if '.php' in winTitle:
    keyboard.send_keys('echo "<pre>[' + label + '] ' + selText_php + '</pre>";')
    exit

if '.js' in winTitle:
    keyboard.send_keys('console.log("[' + label + '] ' + selText_php + '");')
    exit

mapsedge_save.doSave(keyboard, time, window)