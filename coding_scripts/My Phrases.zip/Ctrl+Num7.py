def getLabel():
    secs = str(time.time())
    return secs[-8:]

label = getLabel()
keyboard.send_keys(label)



