import mapsedge_save

def cutSelection():
    keyboard.send_keys("<end>")
    time.sleep(.1)
    keyboard.send_keys("<shift>+<home>")
    time.sleep(.2)
    selText = clipboard.get_selection()
    time.sleep(.6)    
    keyboard.send_keys("<delete>")
    return selText

def getLabel():
    secs = str(time.time())
    return secs[-6:]

def main():
    winTitle = window.get_active_title()
    label = getLabel()

    selText = cutSelection()

    selText2 = selText.replace("\"", "\\\"")
    selText_php = selText2.replace("$", "\$")

    if '.php' in winTitle:
        keyboard.send_keys('die("<pre>[' + label + '] ' + selText_php + ': " . print_r(' + selText + ', 1) . "</pre>");')
        

    if '.js' in winTitle:
        keyboard.send_keys('console.log("[' + label + '] ' + selText_php + '", ' + selText + ');')
        

    mapsedge_save.doSave(keyboard, time, window)
    exit

main()