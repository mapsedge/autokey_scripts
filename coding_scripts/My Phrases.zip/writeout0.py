import sys
import os 
user = os.environ["USER"]

counter = system.exec_command("date '+%s'")
# counter = (int)counter - 1594923133
counter = int(counter) - 1594000000

# Enter script code
time.sleep(.3)
#grab the abbreviation
keyboard.send_keys("<shift>+<ctrl>+<left>")


time.sleep(.3)
keyboard.send_keys("<ctrl>+x")
time.sleep(.1)
abbrev = clipboard.get_selection()
time.sleep(.1)
flag = abbrev[3:]

time.sleep(.1)

#filename = '/home/' + user + '/.config/autokey/data/writeout_counter.txt'
# first create the file if it's not already there
#if os.path.isfile(filename) == False:
#    f = open(filename, 'w')
#    f.write('10000')
#    f.close
    
#f = open(filename, 'r')
#counter = f.read()
#time.sleep(.1)

#counter = int(counter)
#counter = counter + 1
#counter = str(counter)
#f = open(filename, 'w')
#f.write(str(counter))
#f.close

# delete the abbreviation
keyboard.send_keys("<backspace>")



#get the snippet   
keyboard.send_keys("<shift>+<home>")
#keyboard.send_keys("<shift>+<left>")
keyboard.send_keys("<ctrl>+x")
time.sleep(.1)
snip = clipboard.get_selection()


active_title = window.get_active_title()

counter = str(counter)

if '.asp' in active_title:
    keyboard.send_keys('call writeout("[{0}] {1}: " & {1}, {2})'.format(counter.strip(), snip.strip(), flag.strip()).strip())
    
if '.php' in active_title:
    keyboard.send_keys('$s->writeout([\'[{0}] {1}: \' . print_r({1}, 1)], {2});'.format(counter.strip(), snip.strip(), flag.strip()))

if '.js' in active_title:
    keyboard.send_keys('console.log("[{0}] {1}", {1});'.format(counter.strip(), snip.strip()).strip())

#start_time = time.time() 
#if (time.time()-start_time < 0.9):
#    time.sleep(0.2)

keyboard.send_keys("<ctrl>+s")

time.sleep(.7)
window.activate("File Changed")
time.sleep(0.1)
active_title = window.get_active_title()
if (active_title == "File Changed"):
    keyboard.send_key("<enter>")

time.sleep(.7)
window.activate("File Already Exists")
time.sleep(0.1)
active_title = window.get_active_title()
if (active_title == "File Already Exists"):
    keyboard.send_keys("<alt>+o")

