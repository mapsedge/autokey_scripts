# Enter script code
import time

str = '4802098153242751'
for c in str:
    keyboard.send_key(c)
    time.sleep(.2)